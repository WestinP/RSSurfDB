# Path: API\RSsurfDBRepo.py
import mysql.connector
import os
import subprocess
import requests
import arrow

subprocess.call("mysql -u root -proot < Scripts\RSSurfDB.sql", shell=True)

# Get first hour of today
start = arrow.now().floor('day')

# Get last hour of today
end = start.shift(days=+1).floor('day')

db = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="root",
    database="RSsurfDB"
)

cursor = db.cursor()

cursor.execute("SHOW TABLES")

response = requests.get(
    'https://api.stormglass.io/v2/weather/point',
    params={
        'lat': 58.7984,
        'lng': 17.8081,
        'params': ','.join(['windSpeed', 'windDirection', 'waveHeight', 'waveDirection', 'wavePeriod']),
        'start': start.to('UTC'),  # Convert to UTC timestamp
        'end': start.to('UTC')  # Convert to UTC timestamp
    },
    headers={
        'Authorization': '5a269510-ba9e-11ed-bc36-0242ac130002-5a26957e-ba9e-11ed-bc36-0242ac130002'
    }
)

class Hour:
    def __init__(self, time, wave_direction, wave_height, wave_period, wind_direction, wind_speed):
        self.time = time
        self.wave_direction = wave_direction
        self.wave_height = wave_height
        self.wave_period = wave_period
        self.wind_direction = wind_direction
        self.wind_speed = wind_speed

data = response.json()

for hour in data['hours']:
    time = hour['time']
    wave_direction = hour['waveDirection']['sg']
    wave_height = hour['waveHeight']['sg']
    wave_period = hour['wavePeriod']['sg']
    wind_direction = hour['windDirection']['sg']
    wind_speed = hour['windSpeed']['sg']


# Do something with response data.
json_data = response.json()
